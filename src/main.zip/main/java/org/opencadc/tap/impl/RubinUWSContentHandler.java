package org.opencadc.tap.impl;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.csvreader.CsvWriter;

import ca.nrc.cadc.dali.tables.TableData;
import ca.nrc.cadc.dali.tables.TableWriter;
import ca.nrc.cadc.dali.tables.ascii.AsciiTableWriter;
import ca.nrc.cadc.dali.tables.votable.VOTableDocument;
import ca.nrc.cadc.dali.tables.votable.VOTableField;
import ca.nrc.cadc.dali.tables.votable.VOTableReader;
import ca.nrc.cadc.dali.tables.votable.VOTableResource;
import ca.nrc.cadc.dali.tables.votable.VOTableTable;
import ca.nrc.cadc.dali.tables.votable.VOTableWriter;
import ca.nrc.cadc.dali.util.DefaultFormat;
import ca.nrc.cadc.uws.server.RandomStringGenerator;
import ca.nrc.cadc.uws.web.InlineContentException;
import ca.nrc.cadc.uws.web.UWSInlineContentHandler;
import ca.nrc.cadc.dali.util.Format;
import ca.nrc.cadc.dali.util.FormatFactory;
import java.io.Writer;
import java.util.Iterator;


public class RubinUWSContentHandler implements UWSInlineContentHandler {
    private static Logger log = Logger.getLogger(RubinUWSContentHandler.class);

    public static final String US_ASCII = "US-ASCII";

    // CSV format delimiter.
    public static final char CSV_DELI = ',';

    // TSV format delimiter.
    public static final char TSV_DELI = '\t';


    public RubinUWSContentHandler() {
    }

    @Override
    public Content accept(String name, String contentType, InputStream inputStream)
            throws InlineContentException, IOException {
        log.info("name: " + name);
        log.debug("Content-Type: " + contentType);

        if (inputStream == null) {
            throw new IOException("InputStream cannot be null");
        }

        try {
            String baseFilename = name + "-" + new RandomStringGenerator(16).getID();
            String xmlFilename = baseFilename + ".xml";
            String xmlEmptyFilename = baseFilename + ".empty.xml";
            String csvFilename = baseFilename + ".csv";
            String schemaFilename = baseFilename + ".schema.json";

            log.info("Reading VOTable from input stream");
            VOTableReader voTableReader = new VOTableReader();
            VOTableDocument doc = voTableReader.read(inputStream);

            VOTableResource resource = doc.getResourceByType("results");
            if (resource == null && !doc.getResources().isEmpty()) {
                resource = doc.getResources().get(0);
            }

            if (resource == null || resource.getTable() == null) {
                throw new IOException("No table found in the uploaded VOTable");
            }

            VOTableTable table = resource.getTable();
            TableData originalData = table.getTableData();
            List<VOTableField> fields = table.getFields();

            writeSchemaFile(table.getFields(), schemaFilename);

            // Write CSV version of the data
            log.info("Writing CSV to: " + csvFilename);
            OutputStream csvOs = StorageUtils.getOutputStream(csvFilename, "text/csv");
            //TableWriter<VOTableDocument> tableWriter = new AsciiTableWriter(AsciiTableWriter.ContentType.CSV);
            //tableWriter.write(doc, csvOs);

            writeDataWithoutHeaders(fields, originalData, csvOs);

            csvOs.flush();
            csvOs.close();

            // Empty the table data for metadata-only version
            table.setTableData(null);

            // Write empty VOTable for metadata
            log.info("Writing empty VOTable to: " + xmlEmptyFilename);
            OutputStream xmlOsEmpty = StorageUtils.getOutputStream(xmlEmptyFilename, contentType);
            VOTableWriter voWriterEmpty = new VOTableWriter();
            voWriterEmpty.write(doc, xmlOsEmpty);
            xmlOsEmpty.flush();
            xmlOsEmpty.close();

            table.setTableData(originalData);
            

            log.info("Writing full VOTable to: " + xmlFilename);
            OutputStream xmlOs = StorageUtils.getOutputStream(xmlFilename, contentType);
            VOTableWriter voWriter = new VOTableWriter();
            voWriter.write(doc, xmlOs);
            xmlOs.flush();
            xmlOs.close();



            // Return URL to the XML file that contains metadata
            String xmlUrl = StorageUtils.getStorageUrl(xmlFilename);
            log.info("Returning metadata URL: " + xmlUrl);

            Content ret = new Content();
            ret.name = UWSInlineContentHandler.CONTENT_PARAM_REPLACE;
            ret.value = new UWSInlineContentHandler.ParameterReplacement(
                    "param:" + name,
                    xmlUrl);
            return ret;
        } catch (Exception e) {
            log.error("Failed to process VOTable content", e);
            throw new IOException("Failed to process VOTable content: " + e.getMessage(), e);
        }

    }

    /**
     * Write the schema.json file containing the field names and types
     * extracted from the VOTable.
     */
    private void writeSchemaFile(List<VOTableField> fields, String schemaFilename)
            throws IOException {
        log.debug("Writing schema to: " + schemaFilename);
        OutputStream schemaOs = StorageUtils.getOutputStream(schemaFilename, "application/json");
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(schemaOs, "UTF-8"));

        writer.write("[");
        boolean first = true;

        for (VOTableField field : fields) {
            if (!first) {
                writer.write(",");
            }
            first = false;

            writer.write("\n  { ");
            writer.write("\"name\": \"" + escapeJsonString(field.getName()) + "\", ");
            writer.write("\"type\": \"" + escapeJsonString(field.getDatatype()) + "\"");
            writer.write(" }");
        }

        writer.write("\n]");
        writer.flush();
        writer.close();
    }

    /**
     * Helper method to escape special characters in JSON strings
     */
    private String escapeJsonString(String input) {
        if (input == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            switch (c) {
                case '\"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '/':
                    sb.append("\\/");
                    break;
                case '\b':
                    sb.append("\\b");
                    break;
                case '\f':
                    sb.append("\\f");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * Write CSV data without the header row
     */
    private void writeDataWithoutHeaders(List<VOTableField> fields, TableData tableData, OutputStream out)
            throws IOException {
        Writer writer = new BufferedWriter(new OutputStreamWriter(out, US_ASCII));
        CsvWriter csvWriter = new CsvWriter(writer, CSV_DELI);

        try {
            // Initialize the format factory
            FormatFactory formatFactory = new FormatFactory();

            // Initialize the list of associated formats
            List<Format<Object>> formats = new ArrayList<Format<Object>>();
            if (fields != null && !fields.isEmpty()) {
                for (VOTableField field : fields) {
                    Format<Object> format = null;
                    if (field.getFormat() == null) {
                        format = formatFactory.getFormat(field);
                    } else {
                        format = field.getFormat();
                    }
                    formats.add(format);
                }
            }

            // Skip writing headers - just write the data rows
            Iterator<List<Object>> rows = tableData.iterator();
            while (rows.hasNext()) {
                List<Object> row = rows.next();
                if (!fields.isEmpty() && row.size() != fields.size()) {
                    throw new IllegalStateException("cannot write row: " + fields.size() +
                            " metadata fields, " + row.size() + " data columns");
                }

                for (int i = 0; i < row.size(); i++) {
                    Object o = row.get(i);
                    Format<Object> fmt = new DefaultFormat();
                    if (!fields.isEmpty()) {
                        fmt = formats.get(i);
                    }
                    csvWriter.write(fmt.format(o));
                }
                csvWriter.endRecord();
            }
        } catch (Exception ex) {
            throw new IOException("error while writing CSV data", ex);
        } finally {
            csvWriter.flush();
        }
    }
}