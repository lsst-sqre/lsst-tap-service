/*
************************************************************************
*******************  CANADIAN ASTRONOMY DATA CENTRE  *******************
**************  CENTRE CANADIEN DE DONNÉES ASTRONOMIQUES  **************
*
*  (c) 2016.                            (c) 2016.
*  Government of Canada                 Gouvernement du Canada
*  National Research Council            Conseil national de recherches
*  Ottawa, Canada, K1A 0R6              Ottawa, Canada, K1A 0R6
*  All rights reserved                  Tous droits réservés
*
*  NRC disclaims any warranties,        Le CNRC dénie toute garantie
*  expressed, implied, or               énoncée, implicite ou légale,
*  statutory, of any kind with          de quelque nature que ce
*  respect to the software,             soit, concernant le logiciel,
*  including without limitation         y compris sans restriction
*  any warranty of merchantability      toute garantie de valeur
*  or fitness for a particular          marchande ou de pertinence
*  purpose. NRC shall not be            pour un usage particulier.
*  liable in any event for any          Le CNRC ne pourra en aucun cas
*  damages, whether direct or           être tenu responsable de tout
*  indirect, special or general,        dommage, direct ou indirect,
*  consequential or incidental,         particulier ou général,
*  arising from the use of the          accessoire ou fortuit, résultant
*  software.  Neither the name          de l'utilisation du logiciel. Ni
*  of the National Research             le nom du Conseil National de
*  Council of Canada nor the            Recherches du Canada ni les noms
*  names of its contributors may        de ses  participants ne peuvent
*  be used to endorse or promote        être utilisés pour approuver ou
*  products derived from this           promouvoir les produits dérivés
*  software without specific prior      de ce logiciel sans autorisation
*  written permission.                  préalable et particulière
*                                       par écrit.
*
*  This file is part of the             Ce fichier fait partie du projet
*  OpenCADC project.                    OpenCADC.
*
*  OpenCADC is free software:           OpenCADC est un logiciel libre ;
*  you can redistribute it and/or       vous pouvez le redistribuer ou le
*  modify it under the terms of         modifier suivant les termes de
*  the GNU Affero General Public        la “GNU Affero General Public
*  License as published by the          License” telle que publiée
*  Free Software Foundation,            par la Free Software Foundation
*  either version 3 of the              : soit la version 3 de cette
*  License, or (at your option)         licence, soit (à votre gré)
*  any later version.                   toute version ultérieure.
*
*  OpenCADC is distributed in the       OpenCADC est distribué
*  hope that it will be useful,         dans l’espoir qu’il vous
*  but WITHOUT ANY WARRANTY;            sera utile, mais SANS AUCUNE
*  without even the implied             GARANTIE : sans même la garantie
*  warranty of MERCHANTABILITY          implicite de COMMERCIALISABILITÉ
*  or FITNESS FOR A PARTICULAR          ni d’ADÉQUATION À UN OBJECTIF
*  PURPOSE.  See the GNU Affero         PARTICULIER. Consultez la Licence
*  General Public License for           Générale Publique GNU Affero
*  more details.                        pour plus de détails.
*
*  You should have received             Vous devriez avoir reçu une
*  a copy of the GNU Affero             copie de la Licence Générale
*  General Public License along         Publique GNU Affero avec
*  with OpenCADC.  If not, see          OpenCADC ; si ce n’est
*  <http://www.gnu.org/licenses/>.      pas le cas, consultez :
*                                       <http://www.gnu.org/licenses/>.
*
*  $Revision: 4 $
*
************************************************************************
 */

package org.opencadc.tap.impl;

import ca.nrc.cadc.dali.tables.TableData;
import ca.nrc.cadc.dali.tables.TableWriter;
import ca.nrc.cadc.dali.tables.ascii.AsciiTableWriter;
import ca.nrc.cadc.dali.tables.votable.VOTableDocument;
import ca.nrc.cadc.dali.tables.votable.VOTableReader;
import ca.nrc.cadc.dali.tables.votable.VOTableResource;
import ca.nrc.cadc.dali.tables.votable.VOTableTable;
import ca.nrc.cadc.dali.tables.votable.VOTableWriter;
import ca.nrc.cadc.date.DateUtil;
import ca.nrc.cadc.tap.BasicUploadManager;
import ca.nrc.cadc.tap.UploadManager;
import ca.nrc.cadc.tap.db.DatabaseDataType;
import ca.nrc.cadc.tap.db.TableCreator;
import ca.nrc.cadc.tap.db.TableLoader;
import ca.nrc.cadc.tap.db.TapConstants;
import ca.nrc.cadc.tap.schema.ColumnDesc;
import ca.nrc.cadc.tap.schema.TableDesc;
import ca.nrc.cadc.tap.upload.JDOMVOTableParser;
import ca.nrc.cadc.tap.upload.UploadLimits;
import ca.nrc.cadc.tap.upload.UploadParameters;
import ca.nrc.cadc.tap.upload.UploadTable;
import ca.nrc.cadc.tap.upload.VOTableParser;
import ca.nrc.cadc.tap.upload.VOTableParserException;
import ca.nrc.cadc.uws.Job;
import ca.nrc.cadc.uws.Parameter;
import ca.nrc.cadc.uws.server.RandomStringGenerator;
import ca.nrc.cadc.uws.web.UWSInlineContentHandler;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.channels.Channels;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.apache.solr.s3.S3OutputStream;
import org.opencadc.tap.io.TableDataInputStream;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

/**
 *
 * @author stvoutsin
 */
public class RubinUploadManagerImpl extends BasicUploadManager {

    private static final String bucket = System.getProperty("gcs_bucket");
    private static final String bucketURL = System.getProperty("gcs_bucket_url");
    private static final String bucketType = System.getProperty("gcs_bucket_type");

    private static final Logger log = Logger.getLogger(RubinUploadManagerImpl.class);

    // TAP-1.0 xtypes that can just be dropped from ColumnDesc
    private static final List<String> TAP10_XTYPES = Arrays.asList(
            TapConstants.TAP10_CHAR, TapConstants.TAP10_VARCHAR,
            TapConstants.TAP10_DOUBLE, TapConstants.TAP10_REAL,
            TapConstants.TAP10_BIGINT, TapConstants.TAP10_INTEGER, TapConstants.TAP10_SMALLINT);

    public static final int MAX_UPLOAD_ROWS = 100000;

    public static final UploadLimits MAX_UPLOAD;
    /**
     * Use A filesize limit of 32 Mb using UploadLimits.
     */
    static {
        MAX_UPLOAD = new UploadLimits(32 * 1024L * 1024L); // 32 Mb
        MAX_UPLOAD.rowLimit = MAX_UPLOAD_ROWS;
    }

    /**
     * DataSource for the DB.
     */
    protected DataSource dataSource;

    /**
     * Database Specific data type.
     */
    protected DatabaseDataType databaseDataType;

    /**
     * IVOA DateFormat
     */
    protected DateFormat dateFormat;

    /**
     * Limitations on the UPLOAD VOTable.
     */
    protected final UploadLimits uploadLimits;

    protected Job job;

    /**
     * Backwards compatible constructor. This uses the default byte limit of 10MiB.
     *
     * @param rowLimit maximum number of rows
     * @deprecated use UploadLimits instead
     */
    @Deprecated
    protected RubinUploadManagerImpl(int rowLimit) {
        // 10MiB of votable xml is roughly 17k rows x 10 columns
        this(new UploadLimits(10 * 1024L * 1024L));
        this.uploadLimits.rowLimit = rowLimit;
    }

    public RubinUploadManagerImpl() {
        this(MAX_UPLOAD);
    }

    /**
     * Subclass constructor.
     *
     * @param uploadLimits limits on table upload
     */
    public RubinUploadManagerImpl(UploadLimits uploadLimits) {
        super(uploadLimits);
        this.uploadLimits = uploadLimits;
    }

    @Override
    protected void storeTable(TableDesc table, VOTableTable vot) {

        if (table.dataLocation != null) {
            log.info("Table already stored in cloud storage: " + table.dataLocation);
            return; // Table already handled by inline content handler
        }

        try {
            VOTableDocument doc = new VOTableDocument();
            VOTableResource resource = new VOTableResource("results");
            resource.setTable(vot);
            doc.getResources().add(resource);

            String baseFileName = table.getTableName();
            String uniqueId = new RandomStringGenerator(16).getID();

            // Write CSV version
            String csvFileName = baseFileName + "-" + uniqueId + ".csv";
            OutputStream csvOs = getOutputStream(csvFileName, "text/csv");
            TableWriter<VOTableDocument> csvWriter = new AsciiTableWriter(AsciiTableWriter.ContentType.CSV);
            csvWriter.write(doc, csvOs);
            csvOs.flush();
            csvOs.close();

            log.info("CSV File created: " + csvFileName);
            
            TableData tableData = vot.getTableData();
            vot.setTableData(null);

            String xmlFileName = baseFileName + "-" + uniqueId + ".xml";
            OutputStream xmlOs = StorageUtils.getOutputStream(xmlFileName, "application/x-votable+xml");
            VOTableWriter voWriter = new VOTableWriter();
            voWriter.write(doc, xmlOs);
            xmlOs.flush();
            xmlOs.close();
            log.info("XML File created: " + csvFileName);
            
            vot.setTableData(tableData);
 
            URI csvUri = new URI(getStorageBaseUrl() + "/" + csvFileName);
            log.info("CSV file created: " + csvUri);
            table.dataLocation = csvUri;
            log.info("Table " + table.getTableName() + " stored at " + table.dataLocation);
        } catch (Exception e) {
            log.error("Failed to store table in cloud storage", e);
            throw new RuntimeException("Failed to store table in cloud storage", e);
        }
        
    }


    private OutputStream getOutputStream(String filename, String contentType) {
        if (bucketType.equals("S3")) {
            return getOutputStreamS3(filename);
        } else {
            return getOutputStreamGCS(filename, contentType);
        }
    }

    private OutputStream getOutputStreamS3(String filename) {
        S3Configuration config = S3Configuration.builder()
                .pathStyleAccessEnabled(true)
                .useArnRegionEnabled(true)
                .build();

        S3Client s3Client = S3Client.builder()
                .endpointOverride(getURI())
                .serviceConfiguration(config)
                .region(Region.US_WEST_2)
                .build();

        return new S3OutputStream(s3Client, filename, bucket);
    }

    private OutputStream getOutputStreamGCS(String filename, String contentType) {
        Storage storage = StorageOptions.getDefaultInstance().getService();
        BlobId blobId = BlobId.of(bucket, filename);
        BlobInfo blobInfo = BlobInfo.newBuilder(blobId)
                .setContentType("application/x-votable+xml")
                .build();
        Blob blob = storage.create(blobInfo);
        log.info("GCS blob created: " + blob.getSelfLink());
        return Channels.newOutputStream(blob.writer());
    }

    private URI getURI() {
        try {
            return new URI(bucketURL);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(
                    "Invalid bucket URL in configuration: " + e.getMessage(),
                    e);
        }
    }

    private String getStorageBaseUrl() {
        String bucketType = System.getProperty("gcs_bucket_type");
        String bucketURL = System.getProperty("gcs_bucket_url");
        String bucket = System.getProperty("gcs_bucket");
        
        if (bucketType.equals("S3")) {
            return bucketURL + "/" + bucket;
        } else {
            return bucketURL;
        }
    }
    
}
